<!-- main menu footer-->
<div class="main-menu-footer footer-close">
	<div class="header text-xs-center"><a href="#" class="col-xs-12 footer-toggle"><i class="icon-ios-arrow-up"></i></a></div>
	<div class="content">
		<div class="actions">
			<a href="{{url('pos/settings')}}" data-placement="top" data-toggle="tooltip" data-original-title="Settings">
				<span aria-hidden="true" class="icon-cog3"></span>
			</a>
			<a href="javascript: logoutFRM();" data-placement="top" data-toggle="tooltip" data-original-title="Lock">
				<span aria-hidden="true" class="icon-lock4"></span>
			</a>
			<a href="javascript: logoutFRM();" data-placement="top" data-toggle="tooltip" data-original-title="Logout">

				<span aria-hidden="true" class="icon-power3"></span>
			</a>
		</div>
	</div>
</div>
<!-- main menu footer-->

