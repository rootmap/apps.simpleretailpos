---
layout: doc
title: Angularjs
categories: wrappers
permalink: /wrappers/angularjs
---

If you want to use Introjs inside a AngularJS project, you can use the directives in 

- [angular-intro.js](http://code.mendhak.com/angular-intro.js/)

*Do you know a project that we didn't mention here? Please update the documentation on Github or [email](mailto:support@introjs.com) us.*
