<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StripeStoreSetting extends Model
{
    protected $table="stripe_store_settings";
}
