<?php

namespace App\Http\Controllers;

use App\ProductProfit;
use Illuminate\Http\Request;

class ProductProfitController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\ProductProfit  $productProfit
     * @return \Illuminate\Http\Response
     */
    public function show(ProductProfit $productProfit)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\ProductProfit  $productProfit
     * @return \Illuminate\Http\Response
     */
    public function edit(ProductProfit $productProfit)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\ProductProfit  $productProfit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, ProductProfit $productProfit)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\ProductProfit  $productProfit
     * @return \Illuminate\Http\Response
     */
    public function destroy(ProductProfit $productProfit)
    {
        //
    }
}
