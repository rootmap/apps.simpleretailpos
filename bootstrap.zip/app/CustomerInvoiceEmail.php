<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerInvoiceEmail extends Model
{
    //
}
