<div class="modal fade text-xs-left" id="Cash_Out" tabindex="-2" role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
      <h3 class="modal-title" id="myModalLabel35"> Cash Out</h3>
  </div>
  <form>
    <div class="modal-body">
        <div class="form-group row">
            <label class="col-md-4 label-control" for="projectinput1">Amount To Pay Today</label>
            <div class="col-md-8">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="0.00" aria-describedby="button-addon2" data-amount="">
                    <span class="input-group-btn" id="button-addon2">
                        <button class="btn btn-info amountextract" type="button">Exact</button>
                    </span>
                </div>
            </div>
        </div>
     <div class="form-group ">
            <h2 class="text-lg-center text-md-center text-xs-center text-sm-center">
                Your Counter
            </h2>
      </div>
     <div class="form-group text-lg-center text-md-center text-xs-center text-sm-center">
          
            <input type="checkbox" class="switchBootstrap" id="switchBootstrap9" data-on-text="Online" data-off-text="Offline">
          <label for="switcheryColor" class="card-title ml-1">Primary Color Switchery</label>
      </div>

      <div class="form-group row">
        <label class="col-md-4 label-control" for="projectinput1">Remaining</label>

    </div>

    <div class="form-group row">
      <label class="col-md-4 label-control" for="Description">Payment Due</label>
      <div class="col-md-8">
        <span>$0.00</span>
    </div>
</div>
<div class="form-group center">
    <button type="submit" class="btn-lg btn-info">
        <i class="icon-check2"></i> Proceed
    </button>
</div>
</div>
<div class="modal-footer">
    <input type="reset" class="btn btn-outline-secondary btn-lg" data-dismiss="modal" value="close">

</div>
</form>
</div>
</div>
</div>