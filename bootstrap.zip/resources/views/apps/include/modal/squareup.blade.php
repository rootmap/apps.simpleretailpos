<div class="modal fade text-xs-left" id="squareupmodal" tabindex="-3" role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
            <h3 class="modal-title" id="myModalLabel35"> Payment With Square</h3>
      </div>
      <form>
        <div class="modal-body">
            <div id="squareupMsg"></div>
            <iframe id="MainPopupIframe" style="width: 100%; display:block; border:0px; min-height:410px;" src=""></iframe>
        </div>
      </form>
    </div>
  </div>
</div>











