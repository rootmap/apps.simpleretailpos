<div class="modal fade text-xs-left" id="Cash_Out" tabindex="-2" role="dialog" aria-labelledby="myModalLabel35" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
          </button>
          <h3 class="modal-title" id="myModalLabel35">Counter Disply</h3>
      </div>

        <div class="modal-body">
             <div class="form-group ">
                    <h2 class="text-lg-center text-md-center text-xs-center text-sm-center">
                        Your Counter
                    </h2>
              </div>
             <div class="form-group text-lg-center text-md-center text-xs-center text-sm-center">
                    
              </div>     
            </div>
    </div>
    </div>
</div>