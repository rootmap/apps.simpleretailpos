<script type="text/javascript">
    

	//---------------------Test Ajax New Product Start---------------------//
	$(document).ready(function(){

            
            //staripe partial payment End

            //cardpointee and bolt start 
            

        

            

            

	});

</script>