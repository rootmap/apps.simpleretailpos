<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SquareAccount extends Model
{
    protected $table = "square_accounts";
}
