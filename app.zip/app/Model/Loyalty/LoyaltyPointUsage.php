<?php

namespace App\Model\Loyalty;

use Illuminate\Database\Eloquent\Model;

class LoyaltyPointUsage extends Model
{
    //
}
