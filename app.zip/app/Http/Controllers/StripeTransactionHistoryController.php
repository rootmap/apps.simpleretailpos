<?php

namespace App\Http\Controllers;

use App\StripeTransactionHistory;
use Illuminate\Http\Request;

class StripeTransactionHistoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\StripeTransactionHistory  $stripeTransactionHistory
     * @return \Illuminate\Http\Response
     */
    public function show(StripeTransactionHistory $stripeTransactionHistory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\StripeTransactionHistory  $stripeTransactionHistory
     * @return \Illuminate\Http\Response
     */
    public function edit(StripeTransactionHistory $stripeTransactionHistory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\StripeTransactionHistory  $stripeTransactionHistory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, StripeTransactionHistory $stripeTransactionHistory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\StripeTransactionHistory  $stripeTransactionHistory
     * @return \Illuminate\Http\Response
     */
    public function destroy(StripeTransactionHistory $stripeTransactionHistory)
    {
        //
    }
}
